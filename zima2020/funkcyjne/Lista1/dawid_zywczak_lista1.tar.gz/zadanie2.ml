(*Zadanie 2 z listy 1, Dawid Żywczak*)
let rec funca (a: 'a) = funca a;;