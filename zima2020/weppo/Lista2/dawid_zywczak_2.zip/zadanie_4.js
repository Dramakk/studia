/*
typeof x zwracam nam typ przekazywanego argumentu np. 'number'

x instanceof y sprawdza czy x jest instancją obiektu y i zwraca true/false 

*/