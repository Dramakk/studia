const roundUp = 1.5;
const rounded = Math.round(roundUp);
console.log(rounded);