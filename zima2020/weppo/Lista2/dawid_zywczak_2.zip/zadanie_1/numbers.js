let example = 123456789;
console.log(example);