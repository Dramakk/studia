function math (x, y, z){
    return x + (y * z);
}

console.log(53, 61, 67);