import sys
import math as m

def dist(p1, p2):
    a = p2[0] - p1[0]
    b = a**2
    c = p2[1] - p1[1]
    d = c**2
    e = b+d
    f = m.sqrt(e)
    return f


def per(p1, p2, p3):
    return dist(p1, p2)+dist(p2, p3)+dist(p1, p3)

eps = 0.0000000001

def check(x):
    tout = "out/"+str(x)+".out"
    mout = "mine/"+str(x)+".out"
    ft = open(tout,"r")
    twynik = float(ft.read())

    fm = open(mout, "r")
    points = fm.read().split('\n')
    p1 = [int(x) for x in points[0].split()]
    p2 = [int(x) for x in points[1].split()]
    p3 = [int(x) for x in points[2].split()]

    mwynik = per(p1,p2,p3)

    print("Test",x,":")
    print("best:",twynik,"  yours:",mwynik)
    if abs(twynik-mwynik)<=eps:
        print("OK\n")
    else:
        print("Check your answer. Press Enter to continue.")
        input()

i = int(sys.argv[1])
check(i)
